/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author duvan
 */
public class ProcessOne extends Thread{
    
    RunnableProcessOne RunOne = new RunnableProcessOne();
    
    @Override
    public synchronized void run(){
        
        System.out.println("Process One and Process Two Option A...\n\n");
        
        int i=0, j=0;
        while(i<10){
            if(TestThreads.flag1 == true){
            System.out.println("This is process One running...");
            i++;
            TestThreads.flag1 = false;
            }
        }
        
                
        System.out.println("\n\nProcess One and Process Two Option C...\n");
                      
        while(j<5){
            if(TestThreads.flag2 == true){
            System.out.println("\nThis is process One running...");
                try {
                    System.out.println("Process One sleeping...");
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ProcessOne.class.getName()).log(Level.SEVERE, null, ex);
                }
            j++;
            TestThreads.flag2 = false;
            }
        }
        
        System.out.println("\n\nProcess One and Process Two Option B...\n");
        new Thread(RunOne).start();
      
   } 
}
