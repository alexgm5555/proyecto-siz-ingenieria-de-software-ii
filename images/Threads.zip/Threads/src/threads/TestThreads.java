/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

/**
 *
 * @author duvan
 */
public class TestThreads {
    public static volatile boolean flag1 = true;
    public static volatile boolean flag2 = true;
    public static volatile boolean flag3 = true;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           
        ProcessOne One = new ProcessOne();
        ProcessTwo Two = new ProcessTwo();
        
        //ProcessOne y ProcessTwo Opciones A, B y C
        One.start();
        Two.start();     
        
    }
}
