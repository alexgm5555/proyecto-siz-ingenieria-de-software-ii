/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

/**
 *
 * @author duvan
 */
public class RunnableProcessTwo implements Runnable{
    
    public synchronized void run(){
        
        int i=0;
        while(i<10){
            if(TestThreads.flag3 == false){
            System.out.println("This is process Two running...");
            i++;
            TestThreads.flag3 = true;
            }
        }
        
	}
    
}
