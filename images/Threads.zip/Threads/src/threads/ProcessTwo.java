/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author duvan
 */
public class ProcessTwo extends Thread{
    
    RunnableProcessTwo RunTwo = new RunnableProcessTwo();
        
    @Override
    public synchronized void run(){
        int i=0, j=0;
        while(i<10){
            if(TestThreads.flag1 == false){
            System.out.println("This is process Two running...");
            i++;
            TestThreads.flag1 = true;
            }
        }
                        
        while(j<5){
            if(TestThreads.flag2 == false){
            System.out.println("\nThis is process Two running...");
            try {
                System.out.println("Process Two sleeping...");
                Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ProcessTwo.class.getName()).log(Level.SEVERE, null, ex);
                }
            j++;
            TestThreads.flag2 = true;
            }
        }
        
        new Thread(RunTwo).start(); 
   } 
}